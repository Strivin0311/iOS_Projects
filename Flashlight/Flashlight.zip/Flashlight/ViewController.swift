//
//  ViewController.swift
//  Flashlight
//
//  Created by strivin on 2020/9/25.
//

import UIKit

class ViewController: UIViewController {
    let flashlight_on = UIImage(named:"flashlight_on2.png")
    let flashlight_off = UIImage(named:"flashlight_off2.png")
    let blackswift = UIImage(named: "swift.png")
    let grayswift = UIImage(named:"swift2.png")
    
    var switch_state:Bool = false
    
    
    @IBOutlet var swift: UIImageView!
    
    @IBOutlet var `switch`: UIButton!
    
    @IBOutlet var myview: UIView!
    
    @IBAction func `switch`(_ sender: UIButton) {
        if switch_state == false{
            sender.setTitle("OFF", for: .normal)
            sender.setBackgroundImage(flashlight_on, for: .normal)
            sender.setTitleColor(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1), for: .normal)
            myview.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
            swift.image = blackswift
            switch_state = true
        }
        else{
            sender.setTitle("ON",for:.normal)
            sender.setBackgroundImage(flashlight_off, for: .normal)
            sender.setTitleColor(#colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1), for: .normal)
            myview.backgroundColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
            swift.image = grayswift
            switch_state = false
           
        }
    }

}

